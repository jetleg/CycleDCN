/*
 * timedelay.cc
 *
 *  Created on: 2022��2��5��
 *      Author: 13912
 */
// in awgr-->for transmission delay
//delayforopti
#include <stdlib.h>
#include <string.h>
#include <omnetpp.h>
#include "OpticalFrame_m.h"

class EtherFrame;
class timedelay: public cSimpleModule
{
protected:
    //OMNeT++
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();
};

// Register modules.
Define_Module(timedelay)

void timedelay::initialize()
{
}

void timedelay::handleMessage(cMessage *msg)
{
    std::string inGate = msg->getArrivalGate()->getFullName();
    int gateindex = msg->getArrivalGate()->getIndex();
    simtime_t delay = par("delaytime");
    sendDelayed(msg, delay, "out",gateindex);
}

void timedelay::finish()
{
}



