/*
 * coherent.cc
 *
 *  Created on: 2022��3��18��
 *      Author: 13912
 */
/*
 * muxordemux.cc
 *
 *  Created on: 2022��2��2��
 *      Author: 13912
 */
//WdmLayerCom2
#include <stdlib.h>
#include <omnetpp.h>
#include "OpticalFrame_m.h"

class coherent: public cSimpleModule
{
protected:
    //OMNeT++
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();
};

// Register modules.
Define_Module(coherent)

void coherent::initialize()
{
}

void coherent::handleMessage(cMessage *msg)
{
         if(msg->arrivedOn("in")){
         OpticalFrame *frame = check_and_cast<OpticalFrame *>(msg);
         send(frame,"out", frame->getDemuxPath());
         EV << "coherent: msg out from gate"<< frame->getDemuxPath() << endl;
         }
}

void coherent::finish()
{
}







