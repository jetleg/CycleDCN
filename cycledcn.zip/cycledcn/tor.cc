/*
 * tor.cc
 *
 *  Created on: 2022��2��11��
 *      Author: 13912
 */
#include <omnetpp.h>
#include "OpticalFrame_m.h"

class tor : public cSimpleModule
{
  private:
    cMessage *sendMessageEvent;
    simsignal_t lifetimeSignal;

  public:
     tor();
     virtual ~tor();

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual OpticalFrame *generateMessage();
    virtual void finish();
    int numport;
    double load;
    simtime_t begintime;
    simtime_t endtime;
    long numSent;
    long numReceived;
    double txrate;
    double rxrate;
    int sendOrNot;
};

Define_Module(tor);

tor::tor()
{
    sendMessageEvent = NULL;
}

tor::~tor()
{
    cancelAndDelete(sendMessageEvent);
}

void tor::initialize()
{
    sendMessageEvent = new cMessage("sendMessageEvent");
    scheduleAt(simTime(), sendMessageEvent);
    lifetimeSignal = registerSignal("lifetime");
    load = par("load");
    numport = par("numport");
    begintime= simTime();
    sendOrNot = 1;
    numSent = 0;
    numReceived = 0;
    WATCH(numSent);
    WATCH(numReceived);
    txrate = 0;
    rxrate = 0;
    WATCH(txrate);
    WATCH(rxrate);
}

void tor::handleMessage(cMessage *msg)
{
    int torIndex = getIndex();
    if(msg->arrivedOn("in")){
        //if(dynamic_cast<OpticalFrame *>(msg)->getDestination() == getIndex()){
        //if(uniform(0, 1) <= 1){
        EV << "tor: msg received ";
        if(dynamic_cast<OpticalFrame *>(msg)->getDestination()==torIndex){numReceived++;}
            if (dynamic_cast<OpticalFrame *>(msg)->getAwgrAlign()==numport/2){
            simtime_t lifetime = 0.000000133;
            EV << "Received at" << torIndex << ":" << msg->getName() << ", lifetime: " << lifetime << "s" << endl;
            emit(lifetimeSignal, lifetime);}//(simTime() - msg->getCreationTime());
            else{simtime_t lifetime = 0.000000221;
            EV << "Received at" << torIndex << ":" << msg->getName() << ", lifetime: " << lifetime << "s" << endl;
            emit(lifetimeSignal, lifetime);}
        //}
        delete msg;
    }
    else{if(sendOrNot==1){
        sendOrNot = 0;
        ASSERT(msg==sendMessageEvent);
       // if (uniform(0, 1) < load) {
            OpticalFrame *opticalframe = generateMessage();
            //numSent++;//if(numReceived>1){numReceived=numSent;}
            if(opticalframe->getAwgrAlign()==numport/2+2){
                delete opticalframe;
                EV << "msg delete" << endl;
            //if(uniform(0,1)<0.83){numReceived++;}
            }
            else{
                numSent++;
                EV << "sent from" << torIndex << ":" << msg->getName() << endl;
            send(opticalframe, "out");}
        //}
        scheduleAt(simTime()+par("sendIaTime").doubleValue(), sendMessageEvent);}
    }
}

OpticalFrame *tor::generateMessage()
{
    char msgnameopti[30];
    int src = getIndex();
    int lambda = 0;int lambda1 = 0;int lambda2 = 0;int lambda3 = 0;
    //int Alive = 0;
    //int numclient = numport * numport;
    int randomdest = 0;//intuniform(0,numclient-1);
    int demandmat[numport*numport*numport/2][3]= {
            {0,6,2},
            {1,2,2},
            {2,14,1},
            {3,4,0},
            {4,0,4},
            {5,8,0},
            {6,31,1},
            {7,0,3},
            {8,12,3},
            {9,27,0},
            {10,22,3},
            {11,9,3},
            {12,11,1},
            {13,17,0},
            {14,16,3},
            {15,10,3},
            {16,18,3},
            {17,25,1},
            {18,0,4},
            {19,0,4},
            {20,30,0},
            {21,19,3},
            {22,29,3},
            {23,0,4},
            {24,23,3},
            {25,24,3},
            {26,5,1},
            {27,3,0},
            {28,0,4},
            {29,26,2},
            {30,21,0},
            {31,20,1}
    };
    //��matlab�еõ����㷨�Ľ���洢��demandmat�У�����demandmat��src���õ�dest�յ�
    randomdest = demandmat[src][1];//int awg1_index = demand[src][2];
    int demuxPathChoice = randomdest % numport;//randomdest % numport;
    //EV << "demuxPathChoice" << ":" << demuxPathChoice << endl;
    int x=(src/numport)%(numport/2);int y=demandmat[src][2];
    int z=(randomdest/numport)%(numport/2);int p=src/(numport*numport/2);
    int q=randomdest/(numport*numport/2);
    if(y<numport/2){
    lambda1 = y+numport/2-x;
    if(q>=p){lambda2 = q-p;}
    else{lambda2=q-p+numport;}
    lambda3=z-y+numport/2;
   }
   if(y==numport/2){
       if(z>=x){lambda1 = z-x;}
       else{lambda1=z-x+numport;}
   }
    sprintf(msgnameopti, "src-%d-dest-%d-with-%d-demuxPath-%d", src, randomdest, lambda1,demuxPathChoice);
    OpticalFrame *opticalframe = new OpticalFrame(msgnameopti);
    //int wave_new = ( randomdest % numport - src / numport + numport ) % numport; //label
    //opticalframe->setKind(wave_new);
    opticalframe->setSource(src);
    opticalframe->setDestination(randomdest);
    opticalframe->setLambda(lambda1);
    opticalframe->setLambda1(lambda1);
    opticalframe->setLambda2(lambda2);
    opticalframe->setLambda3(lambda3);
    opticalframe->setDemuxPath(demuxPathChoice);
    opticalframe->setByteLength(par("messageLength").longValue());
    opticalframe->setAwgrAlign(y);
    return opticalframe;
}


void tor::finish()
{
    endtime = simTime();

    EV << "Sent:     " << numSent << endl;
    EV << "Received: " << numReceived << endl;
    recordScalar("#sent", numSent);
    recordScalar("#received", numReceived);

    txrate = (numSent * par("messageLength").longValue()*8)/(endtime-begintime);
    rxrate = (numReceived * par("messageLength").longValue()*8)/(endtime-begintime);
    EV << "Txrate:     " << txrate << endl;
    EV << "Rxrate: " << rxrate << endl;
    recordScalar("#txrate", txrate);
    recordScalar("#rxrate", rxrate);
}




