/*
 * packet_loss.cc
 *
 *  Created on: 2022��2��15��
 *      Author: 13912
 */

//chqueue
#include <stdlib.h>
#include <string.h>
#include <omnetpp.h>
#include "OpticalFrame_m.h"

class packet_loss: public cSimpleModule
{
protected:
    //OMNeT++
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();

};

// Register modules.
Define_Module(packet_loss)

void packet_loss::initialize()
{

}

void packet_loss::handleMessage(cMessage *msg)
{
        cChannel *txChannel = gate("out")->getTransmissionChannel();
        simtime_t txFinishTime = txChannel->getTransmissionFinishTime();
        if (txFinishTime <= simTime()){
            send(msg, "out");
        }
        else{
            send(msg, "out");
             //bubble("message lost");
             //delete msg;
        }
}

void packet_loss::finish()
{

}



