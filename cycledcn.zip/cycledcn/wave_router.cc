/*
 * wave_router.cc
 *
 *  Created on: 2022��2��8��
 *      Author: 13912
 */

#include <stdlib.h>
#include <string.h>
#include <omnetpp.h>
#include "OpticalFrame_m.h"

class wave_router: public cSimpleModule
{
protected:
    //OMNeT++
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();
};

// Register modules.
Define_Module(wave_router)

void wave_router::initialize()
{
}

void wave_router::handleMessage(cMessage *msg)
{
    OpticalFrame *arrivalmsg = check_and_cast<OpticalFrame *>(msg);
    int numport = par("numport");
    int arrivallambda = arrivalmsg->getLambda();
    int routerindex = getIndex();//wave_router�ı�ţ�ÿ��waverouter��Ӧһ���˿�
    int gate = (routerindex + arrivallambda) % numport;//����·�ɹ�ʽ
    EV << "msg in waverouter" << routerindex << " send with lambda " << arrivallambda << endl;
    send(arrivalmsg, "out", gate);
}

void wave_router::finish()
{
}




