/*
 * twc2.cc
 *
 *  Created on: 2022��2��16��
 *      Author: 13912
 */

#include <stdio.h>
#include <string.h>
#include <omnetpp.h>
#include "OpticalFrame_m.h"
//#include "Label_m.h"
class twc2 : public cSimpleModule
{
  public:
    twc2();
    virtual ~twc2();
  protected:
    // The following redefined virtual function holds the algorithm.
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish(void);
  private:
    int lambda;
    bool stage;//�ж��Ƿ�����Ҫ����ת���İ�
    cMessage *configTimeEnd;
};

// The module class needs to be registered with OMNeT++
Define_Module(twc2);

twc2::twc2()
{
    configTimeEnd = NULL;
}

twc2::~twc2()
{
    cancelAndDelete(configTimeEnd);
}

void twc2::initialize()
{
    configTimeEnd = new cMessage("configTimeEnd");
    lambda = 0;
    stage = false;
}

void twc2::handleMessage(cMessage *msg)
{
    OpticalFrame *frame = check_and_cast<OpticalFrame *>(msg);
    //if(msg == configTimeEnd){
       //ASSERT(msg==configTimeEnd);
        stage = true;
        lambda = frame->getLambda2();
        EV << " lambda2: " << lambda << endl;
        //EV << "now on and lambda set to"<< lambda <<endl;
    //}
    //if(msg->arrivedOn("control")){
        //Label *labell = check_and_cast<Label *>(msg);
        //stage = false;
        //configTimeEnd->setKind(labell->getLambda());//���ò���Ϊlabel->lambda
        //simtime_t delay2 = par("configtime");
        //scheduleAt(simTime() + delay2, configTimeEnd); //�������ã�ʱ�䣩�󷢰�
        //EV << "off for a while "<< endl;
        //delete msg;//ɾ������twc�Ŀ����ź�
    //}
    if(msg->arrivedOn("in")){
        //if(stage){
            //OpticalFrame *frame = check_and_cast<OpticalFrame *>(msg);
            frame->setLambda(lambda);//lambda = msg->getKind();setKind(control->getLambda())
            //������lamda����Ϊlambda1
            simtime_t delay = par("delaytime");
            sendDelayed(frame, delay, "out");
            EV << "msg in twc2" << frame << " send with lambda1 " << lambda << endl;
        //}
        //else{//˵��������control�˻���δ���������������������İ�stage=1)
            //delete msg;
            //EV << "msg deleted"<<endl;
        //}

    }
}

void twc2::finish()
{
}








