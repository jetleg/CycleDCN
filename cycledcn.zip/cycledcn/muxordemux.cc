/*
 * muxordemux.cc
 *
 *  Created on: 2022��2��2��
 *      Author: 13912
 */
//WdmLayerCom2
#include <stdlib.h>
#include <omnetpp.h>
#include "OpticalFrame_m.h"

class muxordemux: public cSimpleModule
{
protected:
    //OMNeT++
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();
};

// Register modules.
Define_Module(muxordemux)

void muxordemux::initialize()
{
}

void muxordemux::handleMessage(cMessage *msg)
{
    if (msg->arrivedOn("muxin"))
    {
        cChannel *txChannel = gate("muxout")->getTransmissionChannel();
        simtime_t txFinishTime = txChannel->getTransmissionFinishTime();
        //sendDelayed(msg,txFinishTime+simTime(),"muxout");
        sendDelayed(msg,txFinishTime,"muxout");
        //send(msg,"muxout");
        EV << "mux: msg out "<< endl;
    }
    else if(msg->arrivedOn("demuxin"))
    {
         OpticalFrame *frame = check_and_cast<OpticalFrame *>(msg);
         send(frame,"demuxout", frame->getLambda());
         EV << "demux: msg out "<< endl;
     }
    else if(msg->arrivedOn("coherentin")){
        OpticalFrame *frame = check_and_cast<OpticalFrame *>(msg);
        EV << "coherent: msg out form"<< frame->getDemuxPath() << endl;
        send(frame,"coherentout", frame->getDemuxPath());
    }
}

void muxordemux::finish()
{
}



