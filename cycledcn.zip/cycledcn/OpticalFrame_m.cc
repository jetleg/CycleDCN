//
// Generated file, do not edit! Created by nedtool 4.6 from OpticalFrame.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "OpticalFrame_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(OpticalFrame);

OpticalFrame::OpticalFrame(const char *name, int kind) : ::cPacket(name,kind)
{
    this->source_var = 0;
    this->destination_var = 0;
    this->lambda_var = 0;
    this->lambda1_var = 0;
    this->lambda2_var = 0;
    this->lambda3_var = 0;
    this->awgrAlign_var = 0;
    this->demuxPath_var = 0;
}

OpticalFrame::OpticalFrame(const OpticalFrame& other) : ::cPacket(other)
{
    copy(other);
}

OpticalFrame::~OpticalFrame()
{
}

OpticalFrame& OpticalFrame::operator=(const OpticalFrame& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void OpticalFrame::copy(const OpticalFrame& other)
{
    this->source_var = other.source_var;
    this->destination_var = other.destination_var;
    this->lambda_var = other.lambda_var;
    this->lambda1_var = other.lambda1_var;
    this->lambda2_var = other.lambda2_var;
    this->lambda3_var = other.lambda3_var;
    this->awgrAlign_var = other.awgrAlign_var;
    this->demuxPath_var = other.demuxPath_var;
}

void OpticalFrame::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->source_var);
    doPacking(b,this->destination_var);
    doPacking(b,this->lambda_var);
    doPacking(b,this->lambda1_var);
    doPacking(b,this->lambda2_var);
    doPacking(b,this->lambda3_var);
    doPacking(b,this->awgrAlign_var);
    doPacking(b,this->demuxPath_var);
}

void OpticalFrame::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->source_var);
    doUnpacking(b,this->destination_var);
    doUnpacking(b,this->lambda_var);
    doUnpacking(b,this->lambda1_var);
    doUnpacking(b,this->lambda2_var);
    doUnpacking(b,this->lambda3_var);
    doUnpacking(b,this->awgrAlign_var);
    doUnpacking(b,this->demuxPath_var);
}

int OpticalFrame::getSource() const
{
    return source_var;
}

void OpticalFrame::setSource(int source)
{
    this->source_var = source;
}

int OpticalFrame::getDestination() const
{
    return destination_var;
}

void OpticalFrame::setDestination(int destination)
{
    this->destination_var = destination;
}

int OpticalFrame::getLambda() const
{
    return lambda_var;
}

void OpticalFrame::setLambda(int lambda)
{
    this->lambda_var = lambda;
}

int OpticalFrame::getLambda1() const
{
    return lambda1_var;
}

void OpticalFrame::setLambda1(int lambda1)
{
    this->lambda1_var = lambda1;
}

int OpticalFrame::getLambda2() const
{
    return lambda2_var;
}

void OpticalFrame::setLambda2(int lambda2)
{
    this->lambda2_var = lambda2;
}

int OpticalFrame::getLambda3() const
{
    return lambda3_var;
}

void OpticalFrame::setLambda3(int lambda3)
{
    this->lambda3_var = lambda3;
}

int OpticalFrame::getAwgrAlign() const
{
    return awgrAlign_var;
}

void OpticalFrame::setAwgrAlign(int awgrAlign)
{
    this->awgrAlign_var = awgrAlign;
}

int OpticalFrame::getDemuxPath() const
{
    return demuxPath_var;
}

void OpticalFrame::setDemuxPath(int demuxPath)
{
    this->demuxPath_var = demuxPath;
}

class OpticalFrameDescriptor : public cClassDescriptor
{
  public:
    OpticalFrameDescriptor();
    virtual ~OpticalFrameDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(OpticalFrameDescriptor);

OpticalFrameDescriptor::OpticalFrameDescriptor() : cClassDescriptor("OpticalFrame", "cPacket")
{
}

OpticalFrameDescriptor::~OpticalFrameDescriptor()
{
}

bool OpticalFrameDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<OpticalFrame *>(obj)!=NULL;
}

const char *OpticalFrameDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int OpticalFrameDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 8+basedesc->getFieldCount(object) : 8;
}

unsigned int OpticalFrameDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<8) ? fieldTypeFlags[field] : 0;
}

const char *OpticalFrameDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "source",
        "destination",
        "lambda",
        "lambda1",
        "lambda2",
        "lambda3",
        "awgrAlign",
        "demuxPath",
    };
    return (field>=0 && field<8) ? fieldNames[field] : NULL;
}

int OpticalFrameDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='s' && strcmp(fieldName, "source")==0) return base+0;
    if (fieldName[0]=='d' && strcmp(fieldName, "destination")==0) return base+1;
    if (fieldName[0]=='l' && strcmp(fieldName, "lambda")==0) return base+2;
    if (fieldName[0]=='l' && strcmp(fieldName, "lambda1")==0) return base+3;
    if (fieldName[0]=='l' && strcmp(fieldName, "lambda2")==0) return base+4;
    if (fieldName[0]=='l' && strcmp(fieldName, "lambda3")==0) return base+5;
    if (fieldName[0]=='a' && strcmp(fieldName, "awgrAlign")==0) return base+6;
    if (fieldName[0]=='d' && strcmp(fieldName, "demuxPath")==0) return base+7;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *OpticalFrameDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
    };
    return (field>=0 && field<8) ? fieldTypeStrings[field] : NULL;
}

const char *OpticalFrameDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int OpticalFrameDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    OpticalFrame *pp = (OpticalFrame *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string OpticalFrameDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    OpticalFrame *pp = (OpticalFrame *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getSource());
        case 1: return long2string(pp->getDestination());
        case 2: return long2string(pp->getLambda());
        case 3: return long2string(pp->getLambda1());
        case 4: return long2string(pp->getLambda2());
        case 5: return long2string(pp->getLambda3());
        case 6: return long2string(pp->getAwgrAlign());
        case 7: return long2string(pp->getDemuxPath());
        default: return "";
    }
}

bool OpticalFrameDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    OpticalFrame *pp = (OpticalFrame *)object; (void)pp;
    switch (field) {
        case 0: pp->setSource(string2long(value)); return true;
        case 1: pp->setDestination(string2long(value)); return true;
        case 2: pp->setLambda(string2long(value)); return true;
        case 3: pp->setLambda1(string2long(value)); return true;
        case 4: pp->setLambda2(string2long(value)); return true;
        case 5: pp->setLambda3(string2long(value)); return true;
        case 6: pp->setAwgrAlign(string2long(value)); return true;
        case 7: pp->setDemuxPath(string2long(value)); return true;
        default: return false;
    }
}

const char *OpticalFrameDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    };
}

void *OpticalFrameDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    OpticalFrame *pp = (OpticalFrame *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}


